# Spick – Rekryteringsinlägg för Facebook

Använd dessa inlägg i relevanta Facebook-grupper för att rekrytera städare.
Posta som Spick.se-sidan, INTE från din personliga profil.

---

## 🇸🇪 SVENSKA
*Använd i: Städjobb Stockholm, Jobb Stockholm, Hemstädning Sverige*

---

**Vill du bestämma din egen arbetstid och tjäna bra?**

Vi på Spick söker självständiga städare i Stockholm!

✅ Du sätter ditt eget timpris (300–450 kr/h)
✅ Du väljer vilka dagar och tider du jobbar
✅ Du väljer vilka uppdrag du tackar ja till
✅ Betalning direkt efter varje städning via Swish
✅ Vi hjälper dig med F-skatt om du inte har det

Du behöver inte vara anställd – du driver din egen lilla verksamhet och vi förmedlar kunderna till dig.

Är du noggrann, pålitlig och vill ha fler kunder? Skicka en ansökan via vår hemsida eller skriv till oss här!

👉 spick.se/bli-stadare.html

📧 hello@spick.se

---

## 🇺🇦 UKRAINSKA
*Använd i: Ukrainare i Stockholm, Українці в Швеції, Робота в Швеції*

---

**Хочете самі вирішувати свій графік і добре заробляти?**

Ми в Spick шукаємо самозайнятих прибиральників у Стокгольмі!

✅ Ви самі встановлюєте свою погодинну ставку (300–450 кр/год)
✅ Ви обираєте, які дні та години працювати
✅ Ви вирішуєте, які замовлення приймати
✅ Оплата одразу після кожного прибирання через Swish
✅ Ми допоможемо вам з F-skatt, якщо у вас його ще немає

Вам не потрібно бути найманим працівником – ви ведете власний бізнес, а ми знаходимо клієнтів.

Надішліть заявку через наш сайт або напишіть нам тут!

👉 spick.se/bli-stadare.html

📧 hello@spick.se

---

## 🇵🇱 POLSKA
*Använd i: Polacy w Szwecji, Praca Szwecja, Polskie kobiety w Szwecji*

---

**Chcesz sam decydować o swoim harmonogramie i dobrze zarabiać?**

W Spick szukamy samodzielnych sprzątaczy w Sztokholmie!

✅ Sam ustalasz swoją stawkę godzinową (300–450 kr/h)
✅ Wybierasz, które dni i godziny pracujesz
✅ Decydujesz, które zlecenia przyjmujesz
✅ Płatność od razu po każdym sprzątaniu przez Swish
✅ Pomożemy ci z F-skatt, jeśli jeszcze go nie masz

Nie musisz być zatrudniony – prowadzisz własną małą firmę, a my zapewniamy klientów.

Wyślij zgłoszenie przez naszą stronę lub napisz do nas tutaj!

👉 spick.se/bli-stadare.html

📧 hello@spick.se

---

## 🇸🇴 SOMALISKA
*Använd i: Somali i Sverige, Somalier Stockholm, Xiriirka Soomaalida Iswiidhen*

---

**Ma rabtaa inaad go'aamiso jadwalkaaga shaqada oo lacag wanaagsan aad kexeyso?**

Spick waxaan raadinaa nadiifiyeyaal madax-banaan oo ku shaqeeya Stockholm!

✅ Adiga ayaa go'aamiya qiimaha saacadda (300–450 kr/saac)
✅ Adiga ayaa dooranaya maalinta iyo wakhtiga aad shaqeyso
✅ Adiga ayaa go'aamiya hawlaha aad aqbalayso
✅ Lacag-bixinta isla markiiba ka dib nadiifinta kasta iyada oo loo marayo Swish
✅ Waxaan kaa caawin doonaa F-skatt haddaadan haysan

Shaqaalaha ma aha – waxaad leedahay ganacsigaaga yar, annaguna waxaan keenaynaa macaamiisha.

U dir codsigaaga boggeena ama noo qor halkan!

👉 spick.se/bli-stadare.html

📧 hello@spick.se

---

## 🇦🇷 ARABISKA
*Använd i: عرب في السويد, مجتمع العرب في ستوكهولم, عمل في السويد*

---

**هل تريد أن تحدد ساعات عملك بنفسك وتكسب جيداً؟**

نحن في Spick نبحث عن عمال نظافة مستقلين في ستوكهولم!

✅ أنت تحدد سعرك بالساعة (300-450 كرونة/ساعة)
✅ أنت تختار الأيام والساعات التي تعمل فيها
✅ أنت تقرر أي المهام تقبلها
✅ الدفع فوراً بعد كل تنظيف عبر Swish
✅ سنساعدك في الحصول على F-skatt إذا لم يكن لديك

لست موظفاً - أنت تدير مشروعك الصغير الخاص ونحن نجلب لك العملاء.

أرسل طلبك عبر موقعنا أو اكتب لنا هنا!

👉 spick.se/bli-stadare.html

📧 hello@spick.se

---

## 📋 TIPS FÖR BÄST RESULTAT

**Bästa tiderna att posta:**
- Måndag–onsdag 09:00–11:00
- Fredag 18:00–20:00

**Vilka grupper fungerar bäst:**
1. Ukrainare i Stockholm (störst potential)
2. Städjobb Stockholm
3. Jobb Stockholm
4. Polacy w Szwecji
5. Somalier i Sverige

**Svara alltid på kommentarer inom 2 timmar** – intresse svalnar snabbt.

**Vad du skriver när de hör av sig:**
"Hej! Kul att du är intresserad. Fyll i ansökan på spick.se/bli-stadare.html så hör vi av oss inom 24 timmar. 🧹"

**Mål vecka 2:** 50 svar, 10 godkända städare.

# Spick – Google My Business & Kundrekrytering

---

## GOOGLE MY BUSINESS – Sätt upp på 20 minuter (gratis)

### Varför det är viktigt
När någon söker "städning Stockholm" eller "städare nära mig" på Google
visas företag med Google My Business direkt på kartan FÖRE alla hemsidor.
Det är gratis och ger dig kunder utan att du betalar för annonser.

### Steg för steg

1. Gå till: business.google.com
2. Klicka "Hantera nu" → "Lägg till ditt företag"
3. Fyll i:
   - Företagsnamn: Spick
   - Kategori: Städtjänst
   - Adress: (din adress – visas inte publikt om du väljer "Serviceföretag")
   - Serviceområde: Stockholm + Solna + Sundbyberg + Nacka + Lidingö
   - Telefon: (valfritt – kan vara hello@spick.se)
   - Webbplats: spick.se
4. Välj "Jag levererar varor och tjänster till mina kunder"
5. Verifiera via SMS eller brev (brev tar 1-2 veckor)

### Vad du fyller i efter verifiering
- Beskrivning: "Spick är Sveriges smartaste städapp. Boka en betygsatt städare nära dig och betala bara hälften med RUT-avdrag. Vi förmedlar pålitliga, betygsatta städare i Stockholm. Boka enkelt via spick.se."
- Öppettider: Mån–Sön 07:00–20:00
- Foton: Lägg upp 5+ bilder av städade hem (kan vara stockfoton)
- Tjänster: Hemstädning, Flyttstädning, Storstädning, Fönsterputs

### Första recensioner
Be dina första 5 kunder lämna en recension direkt efter jobbet.
Skicka denna SMS: "Hej [namn]! Hoppas städningen gick bra 🧹 Det skulle
hjälpa oss enormt om du lämnar en recension på Google – tar bara 1 minut:
[länk]"

---

## FACEBOOK-INLÄGG FÖR KUNDER

*Posta i: Stockholm tips & råd, Barnfamiljer i Stockholm,
Expats in Stockholm, Hyresgäster Stockholm, Östermalm/Södermalm/Vasastan-grupper*

---

### Inlägg 1 – RUT-fokus

**Visste du att du kan halvera kostnaden för städning?**

Med RUT-avdrag betalar du bara hälften av städkostnaden –
resten betalar Skatteverket direkt till städaren.

Vi på Spick hjälper dig boka en betygsatt städare nära dig.
Du väljer VILKEN städare du vill ha – och kan boka samma person varje vecka.

✅ Betygsatta städare med omdömen
✅ Du väljer din fasta städare
✅ 50% rabatt med RUT-avdrag
✅ Boka online på 2 minuter

👉 spick.se

---

### Inlägg 2 – Personlig städare

**Trött på att förklara för en ny städare varje gång hur du vill ha det?**

På Spick bokar du SAMMA städare varje vecka.

Sara städar åt dig varje tisdag 09:00.
Hon vet exakt hur du vill ha det.
Du behöver inte vara hemma.
Du betalar bara hälften med RUT.

Det är så städning borde fungera.

👉 Hitta din städare på spick.se

---

### Inlägg 3 – Engelsk (för expat-grupper)

**Looking for a reliable cleaner in Stockholm?**

Spick connects you with rated, verified cleaners near you.
You choose your cleaner – and book the same person every week.

✅ Rated cleaners with reviews
✅ Book your regular cleaner
✅ 50% subsidy with RUT (Swedish tax deduction)
✅ Book online in 2 minutes

👉 spick.se

---

### Inlägg 4 – Flytt

**Ska du flytta snart?**

Flyttstädning är det jobbigaste med att flytta – och det dyraste
om du gör det fel och hyresvärden kräver tillbaka depositionspengar.

Vi på Spick förmedlar erfarna flyttstädare i Stockholm som
garanterar ett resultat din hyresvärd godkänner.

Med RUT betalar du bara hälften.

👉 Boka städare på spick.se

---

## TIDPLAN FÖR POSTNING

**Vecka 1 (nu):**
- Mån: Inlägg 1 (RUT-fokus) i Stockholm tips & råd + Barnfamiljer
- Ons: Inlägg 3 (engelska) i Expats in Stockholm
- Fre: Inlägg 2 (personlig städare) i Östermalm-grupper

**Vecka 2:**
- Upprepa med nya grupper
- Börja svara på kommentarer och DM:s
- Lägg till "Kund söker städare i [område]" – fråga gruppen

**Viktigt:** Vänta alltid 2-3 dagar mellan inlägg i samma grupp.
Administratörer kan ta bort spam.
